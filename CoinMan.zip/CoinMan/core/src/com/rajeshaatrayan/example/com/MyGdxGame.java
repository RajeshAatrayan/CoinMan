package com.rajeshaatrayan.example.com;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;

import java.util.ArrayList;
import java.util.Random;

import sun.rmi.runtime.Log;

import static com.badlogic.gdx.Gdx.app;

public class MyGdxGame extends ApplicationAdapter {
    private static final String LOG_TAG = MyGdxGame.class.getSimpleName();
    //With the help of SpriteBatch we draw something onto the screen
    SpriteBatch batch;
    //Texture is a way to add the image to our Game!
    Texture backGround;
    //because coinman have different frames..so we need a an array here
    Texture[] man;
    //Texture for the coin
    Texture coin;
    Texture bomb;
    Texture dizzyFace;
    //to count the number of coins that has been randomly generated
    int coinCount;
    int bombCount;
    int pause = 0;
    int manState = 0;
    float gravity = 0.8f;
    int manY = 0;
    float velocity = 0.0f;
    Random random;
    Rectangle manRectangle;
    int score = 0;
    BitmapFont font;
    int gameState = 0;
    /**
     * coinXs->to get the Xpostion of the coin
     * coinYs->to get the Yposition of the coin
     */
    //coins
    ArrayList<Integer> coinXs = new ArrayList<Integer>();
    ArrayList<Integer> coinYs = new ArrayList<Integer>();

    //bombs
    ArrayList<Integer> bombXs = new ArrayList<Integer>();
    ArrayList<Integer> bombYs = new ArrayList<Integer>();

    //Rectangles
    ArrayList<Rectangle> coinRectangle = new ArrayList<Rectangle>();
    ArrayList<Rectangle> bombRectangle = new ArrayList<Rectangle>();

    /**
     * this method will be called when we first open this activity
     */
    @Override
    public void create() {
        //Initialization of SpriteBatch
        batch = new SpriteBatch();
        //intitialize the texture.....make sure you must mention the .format thing here
        backGround = new Texture("bg.png");
        man = new Texture[]{new Texture("frame-1.png"), new Texture("frame-2.png"), new Texture("frame-3.png"), new Texture("frame-4.png")};
        manY = Gdx.graphics.getHeight() / 2;
        coin = new Texture("coin.png");
        bomb = new Texture("bomb.png");
        dizzyFace = new Texture("dizzy-1.png");
        random = new Random();
        font = new BitmapFont();
        font.setColor(Color.WHITE);
        font.getData().setScale(10);
    }

    private void makeCoin() {
        //here height is the randomly gerenarted thing
        float height = random.nextFloat() * Gdx.graphics.getHeight();
        coinYs.add((int) height);
        coinXs.add(Gdx.graphics.getWidth());
    }

    private void makeBomb() {
        //here height is the randomly gerenarted thing
        float height = random.nextFloat() * Gdx.graphics.getHeight();
        bombYs.add((int) height);
        bombXs.add(Gdx.graphics.getWidth());
    }


    /*
    this render method will be keep on calling untill we finish the game!
     */
    @Override
    public void render() {
        batch.begin();
        //now draw the background image onto the screen
        batch.draw(backGround, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        if (gameState == 1) {
            //Game is live
            /**
             * Here this this is to draw bomb on to the screen
             */
            bombRectangle.clear();
            if (bombCount < 250) {
                bombCount++;
            } else {
                bombCount = 0;
                makeBomb();
            }
            for (int i = 0; i < bombXs.size(); i++) {
                batch.draw(bomb, bombXs.get(i), bombYs.get(i));
                bombXs.set(i, bombXs.get(i) - 8);
                bombRectangle.add(new Rectangle(bombXs.get(i), bombYs.get(i), bomb.getWidth(), bomb.getHeight()));
            }

            //This is for the coins that appear on the screen
            coinRectangle.clear();
            if (coinCount < 100) {
                coinCount++;
            } else {
                coinCount = 0;
                makeCoin();
            }
            for (int i = 0; i < coinXs.size(); i++) {
                batch.draw(coin, coinXs.get(i), coinYs.get(i));
                coinXs.set(i, coinXs.get(i) - 4);
                coinRectangle.add(new Rectangle(coinXs.get(i), coinYs.get(i), coin.getWidth(), coin.getHeight()));
            }
            if (Gdx.input.justTouched()) {
                velocity = -25;
            }
            /**
             * here the pause will keep looping(which takes some time for the iterative operation)
             * and then allow the man to walk by changing the frames
             */
            if (pause < 6) {
                pause++;
            } else {
                if (manState < 3) {
                    manState++;
                } else {
                    manState = 0;
                }
                pause = 0;
            }
            /**
             * not the real velocity but inorder bring our coin man downto the screen
             */
            velocity += gravity;

            manY -= velocity;


            if (manY <= 0)
                manY = 0;
            /**
             * if we set Y=0 the position will be at the bottom of the screen!
             */


        } else if (gameState == 0) {
            //game waiting to start
            if (Gdx.input.justTouched())
                gameState = 1;

        } else if (gameState == 2) {
            //Game finished
            if (Gdx.input.justTouched()) {
                gameState = 1;
                manY = Gdx.graphics.getHeight() / 2;
                score = 0;
                velocity = 0;
                coinXs.clear();
                ;
                coinYs.clear();
                coinCount = 0;
                coinRectangle.clear();
                bombXs.clear();
                bombYs.clear();
                bombRectangle.clear();
                bombCount = 0;
            }

        }
        if (gameState == 2) {
            batch.draw(dizzyFace, Gdx.graphics.getWidth() / 2 - man[manState].getWidth() / 2, manY);
            //font.draw(batch, "Game Over!", 150, manY-18);
        } else {
            batch.draw(man[manState], Gdx.graphics.getWidth() / 2 - man[manState].getWidth() / 2, manY);
        }


        manRectangle = new Rectangle(Gdx.graphics.getWidth() / 2 - man[manState].getWidth() / 2, manY, man[manState].getWidth(), man[manState].getHeight());
        for (int i = 0; i < coinRectangle.size(); i++) {
            if (Intersector.overlaps(manRectangle, coinRectangle.get(i))) {
                score++;
                coinRectangle.remove(i);
                coinXs.remove(i);
                coinYs.remove(i);
                break;
            }
            // Gdx.app.log("Coin","Collision");

        }

        //for bomb

        for (int i = 0; i < bombRectangle.size(); i++) {
            if (Intersector.overlaps(manRectangle, bombRectangle.get(i))) {
                Gdx.app.log("bomb", "Collision");
                gameState = 2;
            }


        }


        font.draw(batch, "" + score, 100, 200);
        batch.end();

    }

    @Override
    public void dispose() {
        batch.dispose();

    }
}
